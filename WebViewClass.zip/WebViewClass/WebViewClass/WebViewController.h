//
//  WebViewController.h
//  WebViewClass
//
//  Created by JiangYu on 2017/3/23.
//  Copyright © 2017年 JiangYu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController

@property (nonatomic,copy) NSString * webUrl;

@end
