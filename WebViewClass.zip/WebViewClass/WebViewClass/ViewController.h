//
//  ViewController.h
//  WebViewClass
//
//  Created by JiangYu on 2017/3/23.
//  Copyright © 2017年 JiangYu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

