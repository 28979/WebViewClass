//
//  ViewController.m
//  WebViewClass
//
//  Created by JiangYu on 2017/3/23.
//  Copyright © 2017年 JiangYu. All rights reserved.
//

#import "ViewController.h"

#import "WebViewController.h"

@interface ViewController ()

@property (nonatomic,strong) UIButton * button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor=[UIColor whiteColor];
    self.title=@"H5套壳";
    for (int i = 0; i < 6; i ++) {
        self.button = [[UIButton alloc]initWithFrame:CGRectMake(140, 130 + i * 50, 100, 40)];
        NSArray * buttonTitleArr = @[@"百度",@"腾讯",@"LoL",@"DNF",@"test1",@"test2"];
        self.button.backgroundColor = [UIColor orangeColor];
        [self.button setTitle:buttonTitleArr[i] forState:UIControlStateNormal];
        [self.button setTintColor:[UIColor whiteColor]];
        [self.button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        self.button.tag = i + 10;
        [self.view addSubview:self.button];
    }
}

-(void)buttonClick:(UIButton *)button{
    WebViewController * webView = [[WebViewController alloc]init];    
    if (button.tag == 10) {
        NSLog(@"-- %ld",button.tag);
        // - 百度
        webView.webUrl = @"https://www.baidu.com";
//        webView.webUrl = @"http://tn8uf3.natappfree.cc/h5/shop/product/loadProductInfoView.dd?shopIdForH5=1c7tk3jb301a3zr10415094s7sgu&productIdForH5=1c7wh4rg900c3zr10418369ujpec&merchantsIdForH5=1c7tjl0fg0163zr10416002cc554&userIdForH5=1c98whyjx08c102h0d39290prufc&houseIdForH5=(null)&companyIdForH5=(null)&companyNoForH5=(null)&signForH5=(null)&fcompanyIdForH5=(null)&qcompanyIdForH5=(null)&userNameForH5=18738103849&accountForH5=18738103849&operatorIdForH5=diandu001&sexForH5=(null)&addressForH5=&type=ios&xsSign=1&parms=dd&identity=visitor";
        webView.navigationItem.title = button.titleLabel.text;
        [self.navigationController pushViewController:webView animated:YES];
    }else if (button.tag == 11){
        NSLog(@"-- %ld",button.tag);
        // - 腾讯
        webView.webUrl = @"http://www.qq.com";
        webView.navigationItem.title = button.titleLabel.text;
        [self.navigationController pushViewController:webView animated:YES];
    }else if (button.tag == 12){
        NSLog(@"-- %ld",button.tag);
        // - LoL
        webView.webUrl = @"http://lol.qq.com";
        webView.navigationItem.title = button.titleLabel.text;
        [self.navigationController pushViewController:webView animated:YES];
    }else if (button.tag == 13){
        NSLog(@"-- %ld",button.tag);
        // - DNF
        webView.webUrl = @"http://dnf.qq.com";
        webView.navigationItem.title = button.titleLabel.text;
        [self.navigationController pushViewController:webView animated:YES];
    }else if (button.tag == 14){
        NSLog(@"-- %ld",button.tag);
        // - CF
        webView.webUrl = @"https://www.chandashi.com/apps/view.html?appId=1447486450";
        webView.navigationItem.title = button.titleLabel.text;
        [self.navigationController pushViewController:webView animated:YES];
    }else if (button.tag == 15){
        NSLog(@"-- %ld",button.tag);
        // - 剑灵
        webView.webUrl = @"https://www.chandashi.com/apps/description/appId/1448261927/country/cn.html";
        webView.navigationItem.title = button.titleLabel.text;
        [self.navigationController pushViewController:webView animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
