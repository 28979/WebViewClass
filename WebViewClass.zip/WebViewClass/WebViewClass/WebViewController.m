//
//  WebViewController.m
//  WebViewClass
//
//  Created by JiangYu on 2017/3/23.
//  Copyright © 2017年 JiangYu. All rights reserved.
//

#import "WebViewController.h"
#import <WebKit/WebKit.h>

/*
    1 - AppDelegate需要设置导航控制器的根视图，你可以按照自己的实际需要来决定根视图
    2 - 引入头文件：#import <WebKit/WebKit.h>
    3 - 在infoplist中设置 apptransport - Allow Arbitrary Loads in Web Content 为 yes
 */

@interface WebViewController ()

@property (nonatomic,strong) WKWebView * webView;

//@property (nonatomic,copy) NSString * navTitle;

@end

@implementation WebViewController

//-(void)viewWillAppear:(BOOL)animated{
//    self.navigationItem.title = self.navTitle;
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createWebView];
}


-(void)createWebView{
    WKWebView * webView = [[WKWebView alloc]initWithFrame:self.view.bounds];

        [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString: _webUrl]]];
    [self.view addSubview:webView];
    self.webView = webView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
